# Runs the full V2 Notion DB build-out (create, sync, wire, docs)
param(
  [string]$RootTitle = "IFNS – UI Master (V2)"
)

python .\scripts\ifns_v2_create_dbs.py --root "$RootTitle" `
  --assets `
    "FeatureSchemaV1=sync/ifns/indicator_feature_schema_v1_with_family.csv:feature_name" `
    "FeatureSchemaH1=sync/ifns/indicator_feature_schema_h1_v1_with_family.csv:feature_name" `
    "PolicyMatrix=sync/ifns/feature_policy_matrix.csv" `
    "FamilyMap=sync/ifns/feature_family_map.csv:feature_name" `
    "UniverseP2=sync/ifns/indicators_universe_catalog_phase2.csv:symbol" `
    "CatalogL1=sync/ifns/indicators_catalog_L1_phase3.csv:indicator_id" `
    "CatalogL2L3=sync/ifns/indicators_catalog_L2L3_phase4.csv:composite_id" `
    "QCWeekly=sync/ifns/qc_weekly_schema_v1.json" `
    "CalendarGaps2025=sync/ifns/calendar_gaps_2025.json"

python .\scripts\ifns_v2_sync_db_generic.py --key FeatureSchemaV1
python .\scripts\ifns_v2_sync_db_generic.py --key FeatureSchemaH1
python .\scripts\ifns_v2_sync_db_generic.py --key PolicyMatrix
python .\scripts\ifns_v2_sync_db_generic.py --key FamilyMap
python .\scripts\ifns_v2_sync_db_generic.py --key UniverseP2
python .\scripts\ifns_v2_sync_db_generic.py --key CatalogL1
python .\scripts\ifns_v2_sync_db_generic.py --key CatalogL2L3

python .\scripts\ifns_v2_sync_qc_weekly.py

python .\scripts\ifns_v2_wire_pages.py --root "$RootTitle"

python .\scripts\ifns_v2_update_local_docs.py
