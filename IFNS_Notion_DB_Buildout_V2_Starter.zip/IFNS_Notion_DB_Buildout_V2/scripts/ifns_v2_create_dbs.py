#!/usr/bin/env python3
"""
Create Notion databases for IFNS V2 and register their IDs.
- Infers properties from CSV header or JSON schema (for QC weekly).
- Stores DB IDs to config/ifns_v2_db_map.json.
"""
import os, sys, json, argparse, csv, re
from typing import Dict, Any, List, Tuple

from notion_client import Client

def guess_type(col: str, sample: str) -> str:
    col_l = col.lower()
    if col_l in ("id", "key", "slug", "name", "feature_name", "indicator_id", "composite_id", "symbol"):
        return "title"
    if col_l.endswith("_date") or col_l in ("date", "ts", "timestamp"):
        return "date"
    if sample is not None and re.fullmatch(r"https?://\S+", sample):
        return "url"
    if sample in ("true", "false"):
        return "checkbox"
    try:
        float(sample)
        return "number"
    except:
        pass
    # heuristic for list-like
    if ";" in sample or "," in sample:
        return "multi_select"
    return "rich_text"

def property_def(notion_type: str) -> Dict[str, Any]:
    return { notion_type: {} }

def load_config(config_path: str) -> Dict[str, Any]:
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(config_path: str, cfg: Dict[str, Any]):
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)

def read_csv_header_and_sample(csv_path: str) -> Tuple[List[str], Dict[str, str]]:
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        sample_row = next(reader, None) or {}
    samples = {h: (sample_row.get(h, "") if sample_row else "") for h in headers}
    return headers, samples

def build_properties(headers: List[str], samples: Dict[str, str], overrides: Dict[str, str]) -> Dict[str, Any]:
    props = {}
    title_set = False
    for h in headers:
        override = overrides.get(h)
        if override:
            nt = override
        else:
            nt = guess_type(h, samples.get(h, ""))
        if nt == "title":
            # only a single title allowed; demote others to rich_text
            if title_set:
                nt = "rich_text"
            else:
                title_set = True
        props[h] = property_def(nt)
    if not title_set and headers:
        # force first column as title
        h0 = headers[0]
        props[h0] = property_def("title")
    return props

def ensure_db(notion: Client, parent_page_id: str, title: str, properties: Dict[str, Any]) -> str:
    # Create a new database under the parent page
    db = notion.databases.create(
        **{
            "parent": {"type": "page_id", "page_id": parent_page_id},
            "title": [{"type": "text", "text": {"content": title}}],
            "properties": properties,
        }
    )
    return db["id"]

def find_page_by_title(notion: Client, parent_page_id: str, title: str) -> str:
    # Search within workspace; we'll filter by title
    res = notion.search(query=title, filter={"value":"page","property":"object"})
    for obj in res.get("results", []):
        if obj.get("object") == "page":
            # best effort title check
            rich = obj.get("properties", {}).get("title", {}).get("title", [])
            txt = "".join([t.get("plain_text","") for t in rich]) if rich else ""
            if txt.strip() == title.strip():
                return obj["id"]
    # Fallback: use the parent page directly (caller must pass correct parent)
    return parent_page_id

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="Root page title in Notion (e.g. 'IFNS – UI Master (V2)')")
    ap.add_argument("--assets", nargs="+", help="key=path[:primary_key] ...")
    ap.add_argument("--config", default="config/ifns_v2_db_map.json")
    args = ap.parse_args()

    token = os.environ.get("NOTION_TOKEN")
    root_page_id_env = os.environ.get("NOTION_ROOT_PAGE_ID")
    if not token:
        print("ERROR: NOTION_TOKEN is not set.")
        sys.exit(1)

    notion = Client(auth=token)

    cfg = load_config(args.config)
    overrides = cfg.get("typing_rules", {})

    # Resolve root page id; we assume env has the correct page already
    parent_page_id = root_page_id_env
    if not parent_page_id:
        # try search by title
        parent_page_id = find_page_by_title(notion, "", args.root)

    for item in args.assets or []:
        key, rest = item.split("=", 1)
        path_pk = rest.split(":")
        fpath = path_pk[0]
        pk = path_pk[1] if len(path_pk) > 1 else ""

        title = key  # DB title
        if fpath.lower().endswith(".csv"):
            headers, samples = read_csv_header_and_sample(fpath)
            props = build_properties(headers, samples, overrides)
        elif fpath.lower().endswith(".json") and "qc_weekly_schema" in os.path.basename(fpath):
            # special: build from JSON schema (draft-07-like)
            import json as _json
            schema = _json.load(open(fpath, "r", encoding="utf-8"))
            props = {}
            props_list = schema.get("properties", {})
            title_set = False
            for name, spec in props_list.items():
                t = spec.get("type", "string")
                nt = {"string":"rich_text","number":"number","integer":"number","boolean":"checkbox","array":"multi_select"}.get(t, "rich_text")
                if name in ("entry_id","id","key") and not title_set:
                    nt = "title"; title_set = True
                props[name] = property_def(nt)
            if not title_set and props_list:
                first = list(props_list.keys())[0]
                props[first] = property_def("title")
        else:
            print(f"Skip unsupported asset: {fpath}")
            continue

        db_id = ensure_db(notion, parent_page_id, title, props)
        cfg["databases"][key]["database_id"] = db_id
        if pk:
            cfg["databases"][key]["primary_key"] = pk

        print(f"Created DB '{key}' → {db_id}")

    save_config(args.config, cfg)
    print("Saved DB map:", args.config)

if __name__ == "__main__":
    main()
