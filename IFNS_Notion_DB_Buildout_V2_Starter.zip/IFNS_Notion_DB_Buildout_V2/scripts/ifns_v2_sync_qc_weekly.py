#!/usr/bin/env python3
"""
QC Weekly sync:
- Ensure DB exists with properties from schema JSON
- Insert seed rows from NDJSON example
"""
import os, sys, json, argparse, ndjson

from notion_client import Client

def ensure_db(notion, parent_page_id, title, properties):
    db = notion.databases.create(parent={"type":"page_id","page_id":parent_page_id},
                                 title=[{"type":"text","text":{"content":title}}],
                                 properties=properties)
    return db["id"]

def as_prop(spec_type, val):
    if spec_type == "title":
        return {"title":[{"type":"text","text":{"content":str(val)[:2000]}}]}
    if spec_type == "number":
        try: return {"number": float(val)}
        except: return {"number": None}
    if spec_type == "boolean":
        return {"checkbox": bool(val)}
    if spec_type == "array":
        items = val if isinstance(val, list) else []
        return {"multi_select":[{"name":str(x)} for x in items]}
    return {"rich_text":[{"type":"text","text":{"content":str(val)[:2000]}}]}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/ifns_v2_db_map.json")
    ap.add_argument("--root_title", default="IFNS – UI Master (V2)")
    args = ap.parse_args()

    token = os.environ.get("NOTION_TOKEN")
    root_id = os.environ.get("NOTION_ROOT_PAGE_ID")
    if not token or not root_id:
        print("ERROR: NOTION_TOKEN / NOTION_ROOT_PAGE_ID missing")
        sys.exit(1)

    notion = Client(auth=token)
    cfg = json.load(open(args.config,"r",encoding="utf-8"))
    db_cfg = cfg["databases"]["QCWeekly"]
    schema_path = db_cfg["path"]
    example_path = "sync/ifns/qc_weekly_example_v1.ndjson"

    schema = json.load(open(schema_path,"r",encoding="utf-8"))
    props = {}
    title_set = False
    for name, spec in schema.get("properties",{}).items():
        t = spec.get("type","string")
        if name in ("entry_id","id","key") and not title_set:
            props[name] = {"title":{}}
            title_set = True
        else:
            nt = {"string":"rich_text","number":"number","integer":"number","boolean":"checkbox","array":"multi_select"}.get(t, "rich_text")
            props[name] = {nt:{}}
    if not title_set and props:
        first = list(props.keys())[0]
        props[first] = {"title":{}}

    # Create DB
    db_id = ensure_db(notion, root_id, "QCWeekly", props)
    cfg["databases"]["QCWeekly"]["database_id"] = db_id
    json.dump(cfg, open(args.config,"w",encoding="utf-8"), indent=2)

    # Seed rows
    with open(example_path,"r",encoding="utf-8") as f:
        reader = ndjson.reader(f)
        for rec in reader:
            p = {}
            for k,v in rec.items():
                t = schema["properties"].get(k,{}).get("type","string")
                if k in ("entry_id","id","key"):
                    p[k] = {"title":[{"type":"text","text":{"content":str(v)}}]}
                else:
                    p[k] = as_prop(t, v)
            try:
                notion.pages.create(parent={"database_id":db_id}, properties=p)
            except Exception as e:
                print("WARN seed fail:", e)

    print("QC weekly DB + seeds synced.")

if __name__ == "__main__":
    main()
