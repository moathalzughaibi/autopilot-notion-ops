#!/usr/bin/env python3
"""
Wire database links under the correct V2 section pages by inserting link_to_page blocks.
"""
import os, sys, json, argparse
from notion_client import Client

SECTIONS = {
    "Manifests & Policy": ["FeatureSchemaV1","FeatureSchemaH1","PolicyMatrix","FamilyMap","UniverseP2","CatalogL1","CatalogL2L3"],
    "Telemetry & QC": ["QCWeekly"],
    "Runtime Templates & Calendars": ["CalendarGaps2025"]
}

def find_child_by_title(notion, parent_page_id, title):
    res = notion.search(query=title, filter={"value":"page","property":"object"})
    for obj in res.get("results", []):
        if obj.get("object") == "page":
            # best effort name matching
            return obj["id"]
    return None

def append_link_block(notion, page_id, target_id, caption):
    notion.blocks.children.append(block_id=page_id, children=[
        {
            "object":"block",
            "type":"paragraph",
            "paragraph":{"rich_text":[{"type":"text","text":{"content":f"{caption}"}}]}
        },
        {
            "object":"block",
            "type":"link_to_page",
            "link_to_page":{"type":"database_id","database_id": target_id}
        }
    ])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--config", default="config/ifns_v2_db_map.json")
    args = ap.parse_args()

    token = os.environ.get("NOTION_TOKEN")
    root_id = os.environ.get("NOTION_ROOT_PAGE_ID")
    if not token or not root_id:
        print("ERROR: NOTION_TOKEN / NOTION_ROOT_PAGE_ID missing")
        sys.exit(1)
    notion = Client(auth=token)

    cfg = json.load(open(args.config,"r",encoding="utf-8"))
    dbs = cfg["databases"]

    # Find section pages by title and attach links
    for section_title, keys in SECTIONS.items():
        section_page_id = find_child_by_title(notion, root_id, section_title) or root_id
        for k in keys:
            db_id = dbs.get(k,{}).get("database_id")
            if db_id:
                append_link_block(notion, section_page_id, db_id, f"{k} — linked database")

    print("Wiring complete.")

if __name__ == "__main__":
    main()
