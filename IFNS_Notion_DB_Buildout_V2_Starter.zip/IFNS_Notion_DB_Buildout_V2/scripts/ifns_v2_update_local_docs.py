#!/usr/bin/env python3
"""
Append entries to local docs:
- docs/IFNS_Notion_Page_Index.md
- docs/IFNS_Troubleshooting_Log.md
Safe to run multiple times (de-dup naive).
"""
import os, sys, json, argparse, hashlib, datetime

def append_line(path, line):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        with open(path,"r",encoding="utf-8") as f: content = f.read()
        if line.strip() in content:
            return
    with open(path,"a",encoding="utf-8") as f:
        f.write(line)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/ifns_v2_db_map.json")
    args = ap.parse_args()

    cfg = json.load(open(args.config,"r",encoding="utf-8"))
    ts = datetime.datetime.utcnow().isoformat()+"Z"

    idx_path = "docs/IFNS_Notion_Page_Index.md"
    tlog_path = "docs/IFNS_Troubleshooting_Log.md"

    append_line(idx_path, f"\n## Notion DB build-out snapshot ({ts})\n")
    for k, info in cfg["databases"].items():
        append_line(idx_path, f"- **{k}** → `{info.get('path','')}` (pk: `{info.get('primary_key','')}`) — DB: `{info.get('database_id','')}`\n")

    append_line(tlog_path, f"\n### {ts} — DB build-out scripts executed\n- Scripts: create_dbs, sync_generic, sync_qc_weekly, wire_pages\n- Notes: file-first, idempotent upserts by primary key.\n")

    print("Local docs updated.")

if __name__ == "__main__":
    main()
