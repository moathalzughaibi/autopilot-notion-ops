#!/usr/bin/env python3
"""
Generic CSV -> Notion DB sync (upsert by primary key).
Usage: python scripts/ifns_v2_sync_db_generic.py --key FeatureSchemaV1
"""
import os, sys, json, argparse, csv, time
from notion_client import Client

def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def ensure_title_value(val: str):
    return [{"type":"text","text":{"content": str(val)[:2000]}}]

def rich_text(val: str):
    return [{"type":"text","text":{"content": str(val)[:2000]}}] if val not in (None,"") else []

def as_property_value(ntype: str, val: str):
    if ntype == "title":
        return {"title": ensure_title_value(val)}
    if ntype == "rich_text":
        return {"rich_text": rich_text(val)}
    if ntype == "number":
        try:
            return {"number": float(val)}
        except:
            return {"number": None}
    if ntype == "checkbox":
        return {"checkbox": str(val).lower() == "true"}
    if ntype == "url":
        return {"url": str(val) if val else None}
    if ntype == "date":
        return {"date": {"start": str(val)}} if val else {"date": None}
    if ntype == "multi_select":
        items = [x.strip() for x in str(val).replace(";", ",").split(",") if x.strip()]
        return {"multi_select": [{"name": it} for it in items]}
    return {"rich_text": rich_text(val)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/ifns_v2_db_map.json")
    ap.add_argument("--key", required=True, help="Database key in config (e.g., FeatureSchemaV1)")
    args = ap.parse_args()

    token = os.environ.get("NOTION_TOKEN")
    if not token:
        print("ERROR: NOTION_TOKEN is not set.")
        sys.exit(1)
    notion = Client(auth=token)

    cfg = load_config(args.config)
    db_cfg = cfg["databases"].get(args.key)
    if not db_cfg:
        print(f"Unknown key: {args.key}")
        sys.exit(1)

    db_id = db_cfg["database_id"]
    csv_path = db_cfg["path"]
    pk = db_cfg.get("primary_key") or ""

    # Fetch database properties to know types
    db = notion.databases.retrieve(db_id=db_id)
    props = db.get("properties", {})
    # invert: name -> type
    ptypes = {name: (spec.get("type")) for name, spec in props.items()}

    created = updated = 0
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Build property payload
            page_props = {}
            for col, val in row.items():
                ntype = ptypes.get(col, "rich_text")
                page_props[col] = as_property_value(ntype, val)

            # Find by primary key if provided
            page_id = None
            if pk and pk in row and row[pk]:
                val = row[pk]
                # query filter
                try:
                    res = notion.databases.query(
                        **{
                            "database_id": db_id,
                            "filter": {
                                "property": pk,
                                ptypes.get(pk, "rich_text"): {"equals": val} if ptypes.get(pk) != "title" else {"equals": val}
                            },
                            "page_size": 1,
                        }
                    )
                    if res.get("results"):
                        page_id = res["results"][0]["id"]
                except Exception as e:
                    # if filter fails on type mismatch, we create and warn
                    print("WARN: query failed, will create:", e)

            try:
                if page_id:
                    notion.pages.update(page_id=page_id, properties=page_props)
                    updated += 1
                else:
                    notion.pages.create(parent={"database_id": db_id}, properties=page_props)
                    created += 1
            except Exception as e:
                print("ERROR on row:", row, "err:", e)

    print(f"Sync complete for {args.key}: created={created}, updated={updated}")

if __name__ == "__main__":
    main()
