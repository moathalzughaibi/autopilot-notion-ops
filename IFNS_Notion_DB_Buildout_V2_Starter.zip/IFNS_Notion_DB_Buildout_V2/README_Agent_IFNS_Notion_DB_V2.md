# Your role — IFNS Notion DB build‑out (V2, file‑first)

Hi,

You are taking the lead on the “Notion DB build‑out” phase for the IFNS project (Intelligent Financial Nerve System). Please assume full responsibility for this phase and only come back if you hit a real blocker (API limits, permissions, or a structural decision). Everything should be done through VS Code + Git, via scripts — **no manual edits in Notion** beyond any unavoidable API limitations noted below.

---

## 0) Context and working model

- **Repo (local):** `E:\GitHub\autopilot-notion-ops`
- **Repo (GitHub):** `moathalzughaibi/autopilot-notion-ops`
- IFNS indicators bundle (v0.10–v0.18) is already unzipped and structured under:
  - `docs/ifns/` (spec pages)
  - `sync/ifns/` (CSV/JSON/NDJSON tables)
  - `etl/`, `tools/`, `.github/workflows/`, `meta_index/`
- In Notion: **IFNS – UI Master (V2)** already exists with section shells (Indicator System; Core ML; Manifests & Policy; Telemetry & QC; Runtime; Change Log; Attachments). Pages for the indicator phases are mirrored; **CSV/JSON stubs** are present but must become **real Notion databases**.

We operate **file‑first**:
- Git (CSV/JSON/MD) is the ultimate source of truth.
- Notion DBs are synced/derived. If Notion disagrees, Git wins.
- All creation, syncing, and wiring is done by Python scripts in `scripts/` and committed to the repo.

---

## 1) Scope (initial DBs)

Create databases and robust sync for:
- **Manifests & Policy**
  - `sync/ifns/indicator_feature_schema_v1_with_family.csv`
  - `sync/ifns/indicator_feature_schema_h1_v1_with_family.csv`
  - `sync/ifns/feature_policy_matrix.csv`
  - `sync/ifns/feature_family_map.csv`
  - `sync/ifns/indicators_universe_catalog_phase2.csv`
  - `sync/ifns/indicators_catalog_L1_phase3.csv`
  - `sync/ifns/indicators_catalog_L2L3_phase4.csv`
- **Telemetry & QC**
  - `sync/ifns/qc_weekly_schema_v1.json` (schema → DB properties)
  - `sync/ifns/qc_weekly_example_v1.ndjson` (seed rows)
- **Runtime / Calendars**
  - `sync/ifns/calendar_gaps_2025.json`
  - (Later) anything under `runtime_templates/**` that needs an index DB.

You may propose more DBs if it reduces operational friction. All must remain file‑first and idempotent.

---

## 2) DB design principles

- Each DB gets a **primary key** (title property). Prefer columns named `key`, `id`, `slug`, `feature_name`, or `symbol`. If none exists, use the first CSV column.
- Property typing heuristic:
  - `*_date` → Date
  - numbers → Number
  - `true/false` → Checkbox
  - `http(s)://` → URL
  - comma/semicolon‑separated lists → Multi‑select
  - everything else → Rich text
- Idempotency: sync scripts **upsert** by primary key (create if missing, update if found).
- No manual edits that conflict with CSVs.
- **Views:** Notion’s public API does not currently expose full database‑view creation. The scripts will create the DB and add a **link block** under the matching V2 page. If a specific grouped view is mandatory, we’ll document a one‑time manual step with filters; otherwise default DB pages are sufficient.

---

## 3) What you will deliver

1. `scripts/`:
   - `ifns_v2_create_dbs.py` — create DBs from CSV/JSON headers and register IDs in `config/ifns_v2_db_map.json`.
   - `ifns_v2_sync_db_generic.py` — generic CSV→DB upsert by primary key.
   - `ifns_v2_sync_qc_weekly.py` — build properties from JSON schema; seed NDJSON rows.
   - `ifns_v2_wire_pages.py` — attach DB links under the correct **IFNS – UI Master (V2)** section pages.
   - `ifns_v2_update_local_docs.py` — append entries to `docs/IFNS_Notion_Page_Index.md` and `docs/IFNS_Troubleshooting_Log.md`.
2. `config/ifns_v2_db_map.json` — maps short names to Notion DB IDs and CSV/JSON paths.
3. Ready‑to‑paste command blocks (see §6).

**Definition of Done**
- All listed assets appear as Notion databases under the correct V2 sections, populated via scripts, linked back to their source files, and re‑runnable at any time.
- Page Index & Troubleshooting Log are auto‑updated by script.

---

## 4) Where things live in Notion

Root container: **IFNS – UI Master (V2)**
- *Manifests & Policy* → all feature schemas, catalogs, family map, policy matrix
- *Telemetry & QC* → QC Weekly DB (schema‑driven) + examples
- *Runtime Templates & Calendars* → Calendar Gaps 2025 + any runtime template indexes

Scripts will resolve page IDs by title under this tree and insert a **link_to_page** block that points to each DB.

---

## 5) Implementation details

- Language: Python 3.10+
- Libraries: `notion-client`, `pandas`, `python-dateutil`, `pyyaml`
- Auth: Run `.\local_env\notion_env.ps1` (sets `NOTION_TOKEN`, `NOTION_ROOT_PAGE_ID`).
- DB creation:
  - Reads CSV headers (or JSON schema) → creates Notion properties.
  - Stores DB IDs to `config\ifns_v2_db_map.json`.
- Sync:
  - Reads CSV rows → queries DB for primary key → create or update.
  - Logs counts and any rejected rows to `logs/` (created if missing).

API caveat: database **views** are not configurable via the public API. We compensate by creating **navigator pages** with direct links and filter suggestions.

---

## 6) Commands (PowerShell, run in repo root)

```powershell
# Prepare a working branch
git checkout -b docs/v2-db-buildout

# (optional) Create and activate venv
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# Install deps
pip install notion-client pandas python-dateutil pyyaml

# Load Notion secrets
.\local_env
otion_env.ps1

# 1) Create DBs from files and register IDs
python .\scripts\ifns_v2_create_dbs.py --root "IFNS – UI Master (V2)" ^
  --assets ^
    "FeatureSchemaV1=sync/ifns/indicator_feature_schema_v1_with_family.csv:feature_name" ^
    "FeatureSchemaH1=sync/ifns/indicator_feature_schema_h1_v1_with_family.csv:feature_name" ^
    "PolicyMatrix=sync/ifns/feature_policy_matrix.csv" ^
    "FamilyMap=sync/ifns/feature_family_map.csv:feature_name" ^
    "UniverseP2=sync/ifns/indicators_universe_catalog_phase2.csv:symbol" ^
    "CatalogL1=sync/ifns/indicators_catalog_L1_phase3.csv:indicator_id" ^
    "CatalogL2L3=sync/ifns/indicators_catalog_L2L3_phase4.csv:composite_id" ^
    "QCWeekly=sync/ifns/qc_weekly_schema_v1.json" ^
    "CalendarGaps2025=sync/ifns/calendar_gaps_2025.json"

# 2) Sync CSV-backed DBs
python .\scripts\ifns_v2_sync_db_generic.py --key FeatureSchemaV1
python .\scripts\ifns_v2_sync_db_generic.py --key FeatureSchemaH1
python .\scripts\ifns_v2_sync_db_generic.py --key PolicyMatrix
python .\scripts\ifns_v2_sync_db_generic.py --key FamilyMap
python .\scripts\ifns_v2_sync_db_generic.py --key UniverseP2
python .\scripts\ifns_v2_sync_db_generic.py --key CatalogL1
python .\scripts\ifns_v2_sync_db_generic.py --key CatalogL2L3

# 3) QC weekly (schema + examples)
python .\scripts\ifns_v2_sync_qc_weekly.py

# 4) Wire DB links into the V2 section pages
python .\scripts\ifns_v2_wire_pages.py --root "IFNS – UI Master (V2)"

# 5) Update local docs (Page Index & Troubleshooting)
python .\scripts\ifns_v2_update_local_docs.py

# Commit & push
git add .
git commit -m "[V2] Notion DB build-out — create & sync + wiring + docs"
git push origin docs/v2-db-buildout
```

---

## 7) Troubleshooting / escalation

- If a DB fails to create due to permissions, verify `NOTION_ROOT_PAGE_ID` points to the V2 root and the integration has **edit** access.
- If a CSV has no obvious primary key, propose one (or add a stable `key` column to the CSV and re‑run).
- If you must modify typing for a specific column, add a rule to `config\ifns_v2_db_map.json` (see examples inside) and re‑run creation.
- Raise an issue only for hard blockers (API/permissions) or structural changes.

---

## 8) Definition of Done (operator view)

- Operator can re‑run sync with **one command per DB**.
- Each V2 section shows working DB links with a one‑paragraph “What is this?” explainer.
- `docs/IFNS_Notion_Page_Index.md` lists the new DBs with purpose + CSV path.
- `docs/IFNS_Troubleshooting_Log.md` contains your key decisions and any caveats.

Thanks! Ship this as a clean, idempotent, script‑driven layer.
